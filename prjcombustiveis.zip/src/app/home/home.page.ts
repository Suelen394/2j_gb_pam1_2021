import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  

  constructor(){}
  calcular (indice: number): void{
    rp= pe/pg;

  if(rp<0.7){
    
  } else if(rp>0.7){

  } else if(rp==0.7){

  }
  selecoes = [
    
  ];
  selecao = 'posto.jpg';
  }

}

